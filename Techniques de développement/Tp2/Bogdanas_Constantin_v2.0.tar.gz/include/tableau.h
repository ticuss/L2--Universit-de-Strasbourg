#ifndef __tableau_h__
#define __tableau_h__


typedef struct {
	int* valeurs ;
	int taille ;
} tableau ;

#endif
