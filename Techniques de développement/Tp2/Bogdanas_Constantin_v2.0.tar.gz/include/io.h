#include <stdio.h>
#include "tableau.h" 
#ifndef __io_h__
#define __io_h__

extern tableau t ;

// affiche le tableau
void affiche();

#endif
