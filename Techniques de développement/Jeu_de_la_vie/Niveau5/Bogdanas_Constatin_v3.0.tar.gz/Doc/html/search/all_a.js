var searchData=
[
  ['paint_5fbackground',['paint_background',['../graphics_8h.html#ab36bb7b7e31d92a0f4aefe0313c22e2f',1,'paint_background(cairo_surface_t *surface):&#160;graphics.c'],['../graphics_8c.html#ab36bb7b7e31d92a0f4aefe0313c22e2f',1,'paint_background(cairo_surface_t *surface):&#160;graphics.c']]],
  ['paint_5fsquare',['paint_square',['../graphics_8h.html#abf4ac59f5630d69ddb105284cb2cba13',1,'paint_square(cairo_surface_t *surface, grille *g, int showlife):&#160;graphics.c'],['../graphics_8c.html#abf4ac59f5630d69ddb105284cb2cba13',1,'paint_square(cairo_surface_t *surface, grille *g, int showlife):&#160;graphics.c']]],
  ['print_5flife',['print_life',['../graphics_8c.html#af0f0f2e1246a30726ba6a4545fd07ca5',1,'graphics.c']]],
  ['print_5fstring',['print_string',['../graphics_8h.html#a539f312ec608613e1efb92a9dfc78564',1,'print_string(cairo_surface_t *surface, char *str, double pos_xt, double pos_yt, double t_size):&#160;graphics.c'],['../graphics_8c.html#a539f312ec608613e1efb92a9dfc78564',1,'print_string(cairo_surface_t *surface, char *str, double pos_xt, double pos_yt, double t_size):&#160;graphics.c']]]
];
