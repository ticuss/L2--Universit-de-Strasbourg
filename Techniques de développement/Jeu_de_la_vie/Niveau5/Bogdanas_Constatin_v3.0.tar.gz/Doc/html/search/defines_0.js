var searchData=
[
  ['gap',['GAP',['../settings_8h.html#a2a2129b3f6b7ce06869b7f16b81aff6f',1,'settings.h']]]
];
