var searchData=
[
  ['cellules',['cellules',['../structgrille.html#a428cf0c0297ce04e0206ba0067ac3b42',1,'grille']]],
  ['compte_5fvoisins_5fvivants_5fcyclique',['compte_voisins_vivants_cyclique',['../jeu_8h.html#a919a35926d94b71717909ecc50233f26',1,'compte_voisins_vivants_cyclique(int i, int j, grille g):&#160;jeu.c'],['../jeu_8c.html#a919a35926d94b71717909ecc50233f26',1,'compte_voisins_vivants_cyclique(int i, int j, grille g):&#160;jeu.c']]],
  ['compte_5fvoisins_5fvivants_5fnon_5fcyclique',['compte_voisins_vivants_non_cyclique',['../jeu_8h.html#a2e8fdd206d197391527920bbbc137eef',1,'compte_voisins_vivants_non_cyclique(int i, int j, grille g):&#160;jeu.c'],['../jeu_8c.html#a2e8fdd206d197391527920bbbc137eef',1,'compte_voisins_vivants_non_cyclique(int i, int j, grille g):&#160;jeu.c']]],
  ['copie_5fgrille',['copie_grille',['../grille_8h.html#aa056fcb4fe6e701c92be5237a589dee2',1,'copie_grille(const grille *gs, grille *gd):&#160;grille.c'],['../grille_8c.html#a79da7a2194caacae6741daf305bdbf6e',1,'copie_grille(const grille *const gs, grille *const gd):&#160;grille.c']]],
  ['corp_5fjeu',['corp_jeu',['../graphics_8h.html#a2c524d9f799840c628807466626f3c0b',1,'corp_jeu(grille *g, grille *gc, cairo_surface_t *cs, XEvent e, Display *dpy):&#160;graphics.c'],['../graphics_8c.html#a2c524d9f799840c628807466626f3c0b',1,'corp_jeu(grille *g, grille *gc, cairo_surface_t *cs, XEvent e, Display *dpy):&#160;graphics.c']]]
];
