var searchData=
[
  ['set_5fmorte',['set_morte',['../grille_8h.html#a10e7b11f2de74ccf95ad1fcb3671a163',1,'set_morte(int i, int j, grille g):&#160;grille.h'],['../grille_8c.html#a3c8e6e08e82824278fdf45a4a05dc85a',1,'set_morte(int i, int j, grille g):&#160;grille.c']]],
  ['set_5fmute',['set_mute',['../structgrille.html#ac9963b54490bc7948e172420da9e683c',1,'grille::set_mute()'],['../grille_8c.html#ac9963b54490bc7948e172420da9e683c',1,'set_mute():&#160;grille.c']]],
  ['set_5fnonviable',['set_nonViable',['../structgrille.html#a86855af77506e0c3058162ca506501d8',1,'grille']]],
  ['set_5fvivante',['set_vivante',['../grille_8h.html#a32d986d81f64f5bf9a58653accac0310',1,'set_vivante(int i, int j, grille g):&#160;grille.h'],['../grille_8c.html#ae0cbadbe963314bacd54c1a1ea511da7',1,'set_vivante(int i, int j, grille g):&#160;grille.c']]]
];
