var searchData=
[
  ['set_5fmorte',['set_morte',['../grille_8h.html#a10e7b11f2de74ccf95ad1fcb3671a163',1,'set_morte(int i, int j, grille g):&#160;grille.h'],['../grille_8c.html#a3c8e6e08e82824278fdf45a4a05dc85a',1,'set_morte(int i, int j, grille g):&#160;grille.c']]],
  ['set_5fmute',['set_mute',['../structgrille.html#ac9963b54490bc7948e172420da9e683c',1,'grille::set_mute()'],['../grille_8c.html#ac9963b54490bc7948e172420da9e683c',1,'set_mute():&#160;grille.c']]],
  ['set_5fnonviable',['set_nonViable',['../structgrille.html#a86855af77506e0c3058162ca506501d8',1,'grille']]],
  ['set_5fvivante',['set_vivante',['../grille_8h.html#a32d986d81f64f5bf9a58653accac0310',1,'set_vivante(int i, int j, grille g):&#160;grille.h'],['../grille_8c.html#ae0cbadbe963314bacd54c1a1ea511da7',1,'set_vivante(int i, int j, grille g):&#160;grille.c']]],
  ['settings_2eh',['settings.h',['../settings_8h.html',1,'']]],
  ['sizex',['SIZEX',['../settings_8h.html#a3d6d12a6ee0d7d77f3f180ed1b2a1e22',1,'settings.h']]],
  ['sizey',['SIZEY',['../settings_8h.html#a7e1991fcd344daa8c9e423cfd3481a8c',1,'settings.h']]],
  ['stagex',['STAGEX',['../settings_8h.html#a67ad60d68dfd8f30936b23900d2a7d2b',1,'settings.h']]],
  ['stagey',['STAGEY',['../settings_8h.html#a446a17435c91a6fbbad1a6d249c65fd0',1,'settings.h']]]
];
