var searchData=
[
  ['read_20me_20first_21',['Read me First!',['../md_README.html',1,'']]],
  ['readme_2emd',['README.md',['../README_8md.html',1,'']]]
];
