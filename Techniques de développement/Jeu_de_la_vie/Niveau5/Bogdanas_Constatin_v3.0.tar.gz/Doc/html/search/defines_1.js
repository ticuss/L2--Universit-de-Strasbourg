var searchData=
[
  ['sizex',['SIZEX',['../settings_8h.html#a3d6d12a6ee0d7d77f3f180ed1b2a1e22',1,'settings.h']]],
  ['sizey',['SIZEY',['../settings_8h.html#a7e1991fcd344daa8c9e423cfd3481a8c',1,'settings.h']]],
  ['stagex',['STAGEX',['../settings_8h.html#a67ad60d68dfd8f30936b23900d2a7d2b',1,'settings.h']]],
  ['stagey',['STAGEY',['../settings_8h.html#a446a17435c91a6fbbad1a6d249c65fd0',1,'settings.h']]]
];
