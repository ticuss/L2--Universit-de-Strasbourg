var searchData=
[
  ['init_5fgrille_5ffrom_5ffile',['init_grille_from_file',['../grille_8h.html#ac247d94af4c53fe64b28236f0a507bf0',1,'init_grille_from_file(char const *const filename, grille *g):&#160;grille.c'],['../grille_8c.html#ae02ff155084ab0c3a9ccc4a37b9ba4e6',1,'init_grille_from_file(char const *const filename, grille *const g):&#160;grille.c']]]
];
