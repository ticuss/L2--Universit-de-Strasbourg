var searchData=
[
  ['affiche_5fgrille',['affiche_grille',['../io_8h.html#ae9ad1477363fc79cb8c0606507d1ca22',1,'affiche_grille(const grille *g, void(*affiche_ligne)(int, const grille *)):&#160;io.c'],['../io_8c.html#ae9ad1477363fc79cb8c0606507d1ca22',1,'affiche_grille(const grille *g, void(*affiche_ligne)(int, const grille *)):&#160;io.c']]],
  ['affiche_5fligne_5fo',['affiche_ligne_o',['../io_8h.html#ae5f7318fa7604cdb6fdabb6f7c22c5d5',1,'affiche_ligne_o(int ligne, const grille *g):&#160;io.c'],['../io_8c.html#ae5f7318fa7604cdb6fdabb6f7c22c5d5',1,'affiche_ligne_o(int ligne, const grille *g):&#160;io.c']]],
  ['affiche_5fligne_5fv',['affiche_ligne_v',['../io_8h.html#af9563198ff65da1f42a007c4a0f1c15f',1,'affiche_ligne_v(int ligne, const grille *g):&#160;io.c'],['../io_8c.html#af9563198ff65da1f42a007c4a0f1c15f',1,'affiche_ligne_v(int ligne, const grille *g):&#160;io.c']]],
  ['affiche_5ftrait',['affiche_trait',['../io_8h.html#a634cf584c380ce221d5d4199f3e813bd',1,'affiche_trait(int c):&#160;io.c'],['../io_8c.html#a634cf584c380ce221d5d4199f3e813bd',1,'affiche_trait(int c):&#160;io.c']]],
  ['alloue_5fgrille',['alloue_grille',['../grille_8h.html#ae621f51c60aa4fafaa0c9f6c9b5a4036',1,'alloue_grille(int l, int c, grille *g):&#160;grille.c'],['../grille_8c.html#ae621f51c60aa4fafaa0c9f6c9b5a4036',1,'alloue_grille(int l, int c, grille *g):&#160;grille.c']]]
];
