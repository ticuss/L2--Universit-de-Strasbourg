var searchData=
[
  ['efface_5fgrille',['efface_grille',['../io_8h.html#a2115a1f8443f23ac84b5ab17c31ce2db',1,'efface_grille(const grille *g):&#160;io.c'],['../io_8c.html#a2115a1f8443f23ac84b5ab17c31ce2db',1,'efface_grille(const grille *g):&#160;io.c']]],
  ['est_5fnonviable',['est_nonViable',['../structgrille.html#a4a09035c33865ee6ff8db67aff3d3af2',1,'grille']]],
  ['est_5fvivante',['est_vivante',['../grille_8h.html#aa814881babc3a8e277963a9083c5ebb0',1,'est_vivante(int i, int j, grille g):&#160;grille.h'],['../grille_8c.html#aa814881babc3a8e277963a9083c5ebb0',1,'est_vivante(int i, int j, grille g):&#160;grille.h']]],
  ['evolue',['evolue',['../jeu_8h.html#a79c0c5a7d9c19a240c8fd1ae2fe63451',1,'evolue(grille *g, grille *gc, int(*compte_voisins_vivants)(int, int, grille)):&#160;jeu.c'],['../jeu_8c.html#a79c0c5a7d9c19a240c8fd1ae2fe63451',1,'evolue(grille *g, grille *gc, int(*compte_voisins_vivants)(int, int, grille)):&#160;jeu.c']]]
];
