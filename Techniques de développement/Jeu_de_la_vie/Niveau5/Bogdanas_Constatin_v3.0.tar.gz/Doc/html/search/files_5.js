var searchData=
[
  ['settings_2eh',['settings.h',['../settings_8h.html',1,'']]]
];
