var settings_8h =
[
    [ "GAP", "settings_8h.html#a2a2129b3f6b7ce06869b7f16b81aff6f", null ],
    [ "SIZEX", "settings_8h.html#a3d6d12a6ee0d7d77f3f180ed1b2a1e22", null ],
    [ "SIZEY", "settings_8h.html#a7e1991fcd344daa8c9e423cfd3481a8c", null ],
    [ "STAGEX", "settings_8h.html#a67ad60d68dfd8f30936b23900d2a7d2b", null ],
    [ "STAGEY", "settings_8h.html#a446a17435c91a6fbbad1a6d249c65fd0", null ]
];