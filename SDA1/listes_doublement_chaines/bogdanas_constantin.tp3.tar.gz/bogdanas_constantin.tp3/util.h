#ifndef _UTIL_H
#define _UTIL_H

#define UTIL_TEXT_RESET "\033[0m"
#define UTIL_TEXT_DIM "\033[2m"
#define UTIL_TEXT_BOLD "\033[1m"

#define UTIL_TEXT_BLACK "\033[30m"
#define UTIL_TEXT_RED "\033[31m"
#define UTIL_TEXT_GREEN "\033[32m"
#define UTIL_TEXT_YELLOW "\033[33m"
#define UTIL_TEXT_BLUE "\033[34m"
#define UTIL_TEXT_MAGENTA "\033[35m"
#define UTIL_TEXT_CYAN "\033[36m"
#define UTIL_TEXT_WHITE "\033[37m"

#endif
