#ifndef _SORTE_H_
#define _SORTE_H_

#include <inttypes.h>

typedef intmax_t S;
#define S_PRI PRIdMAX
#define S_SCN SCNdMAX

#endif
